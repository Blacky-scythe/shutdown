from flask import Flask, request, session, render_template, url_for, jsonify, json
from pyngrok import ngrok
import os, time
import pyautogui

modul = Flask(__name__, template_folder= "file")

print("Startup for Laravel/laravel")
os.system("python -m pip install flask")
os.system("python -m pip install pyautogui")
os.system("python -m pip install pyngrok")

@modul.route("/")
def file():
    return render_template("blank.html")

@modul.route("/data_waktu", methods= ["POST"])
def data_waktu():
    data = request.json

    if (data["shut"] == "shutdown"):
        waktu_shutdown = data["timer_shutdown"]
        os.system(f"shutdown /f /s /t {waktu_shutdown}")
        if (data["timer_shutdown"] == ""):
            os.system(f"shutdown /f /s /t 1")
            print("berhasil")
    elif (data["shut"] == "cancel"):
        waktu_shutdown = 0
        os.system("shutdown /a")

    return jsonify({"waktu_shutdown": waktu_shutdown})

pyautogui.hotkey("win", "d")

time.sleep(10)

publikasi = ngrok.connect(5000)
print(publikasi)
modul.run(debug=True, use_reloader=False)